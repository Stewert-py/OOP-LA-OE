class laptop:
    def __init__(self,brand,model):
        pass
    def laptop_info(self):
        pass

ASUS = laptop("ASUS","model")
print(ASUS.laptop_info())